import flet as ft

from inventory import AbstractEntity, InventoryProduct, ProductIndex


class InventoryWindow(AbstractEntity):
    def __init__(self, page: ft.Page):
        self.page = page
        self.catalog = ProductIndex.seed_inventory()
        self.query = ""
        self.category = "Все категории"
        self.product_list = ft.ListView(expand=True, spacing=10, controls=[])
        self.total_value = ft.Text("0,00 ₽", size=22, weight=ft.FontWeight.BOLD)
        self.total_products = ft.Text("0", size=22, weight=ft.FontWeight.BOLD)
        self.total_units = ft.Text("0", size=22, weight=ft.FontWeight.BOLD)
        self.low_stock = ft.Text("0", size=22, weight=ft.FontWeight.BOLD)
        self.search_field = ft.TextField(
            label="Поиск товаров",
            hint_text="Название или артикул",
            prefix_icon=ft.Icons.SEARCH,
            width=420,
            filled=True,
            fill_color=ft.Colors.WHITE,
            border_radius=12,
            border_color=ft.Colors.GREY_300,
            content_padding=ft.Padding.symmetric(horizontal=16, vertical=14),
            on_change=self.on_search,
        )
        self.category_dropdown = ft.Dropdown(
            label="Категория",
            value="Все категории",
            options=[ft.DropdownOption(text="Все категории")],
            width=230,
            filled=True,
            fill_color=ft.Colors.WHITE,
            border_radius=12,
            border_color=ft.Colors.GREY_300,
            content_padding=ft.Padding.symmetric(horizontal=16, vertical=14),
            on_select=self.on_category,
        )

    @property
    def page(self) -> ft.Page:
        return self._page

    @page.setter
    def page(self, value: ft.Page) -> None:
        self._page = value

    @property
    def catalog(self) -> ProductIndex:
        return self._catalog

    @catalog.setter
    def catalog(self, value: ProductIndex) -> None:
        self._catalog = value

    @property
    def query(self) -> str:
        return self._query

    @query.setter
    def query(self, value: str) -> None:
        self._query = value

    @property
    def category(self) -> str:
        return self._category

    @category.setter
    def category(self, value: str) -> None:
        self._category = value

    @property
    def product_list(self) -> ft.ListView:
        return self._product_list

    @product_list.setter
    def product_list(self, value: ft.ListView) -> None:
        self._product_list = value

    @property
    def total_value(self) -> ft.Text:
        return self._total_value

    @total_value.setter
    def total_value(self, value: ft.Text) -> None:
        self._total_value = value

    @property
    def total_products(self) -> ft.Text:
        return self._total_products

    @total_products.setter
    def total_products(self, value: ft.Text) -> None:
        self._total_products = value

    @property
    def total_units(self) -> ft.Text:
        return self._total_units

    @total_units.setter
    def total_units(self, value: ft.Text) -> None:
        self._total_units = value

    @property
    def low_stock(self) -> ft.Text:
        return self._low_stock

    @low_stock.setter
    def low_stock(self, value: ft.Text) -> None:
        self._low_stock = value

    @property
    def search_field(self) -> ft.TextField:
        return self._search_field

    @search_field.setter
    def search_field(self, value: ft.TextField) -> None:
        self._search_field = value

    @property
    def category_dropdown(self) -> ft.Dropdown:
        return self._category_dropdown

    @category_dropdown.setter
    def category_dropdown(self, value: ft.Dropdown) -> None:
        self._category_dropdown = value

    def display_name(self) -> str:
        return "Stockroom Inventory window"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, InventoryWindow):
            return NotImplemented
        return self.catalog == other.catalog

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, InventoryWindow):
            return NotImplemented
        return self.catalog < other.catalog

    def __repr__(self) -> str:
        return f"InventoryWindow(products={len(self.catalog)})"

    def __str__(self) -> str:
        return f"Inventory dashboard · {len(self.catalog)} products"

    def build(self) -> None:
        self.page.title = "Склад товаров"
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.bgcolor = ft.Colors.GREY_50
        self.page.padding = 24
        self.page.add(
            ft.Column(
                expand=True,
                spacing=18,
                controls=[
                    self.make_header(),
                    ft.Row(
                        wrap=True,
                        spacing=12,
                        run_spacing=12,
                        controls=[self.search_field, self.category_dropdown],
                    ),
                    self.make_summary(),
                    ft.Row(
                        controls=[
                            ft.Text("Товары", size=20, weight=ft.FontWeight.BOLD),
                            ft.Container(expand=True),
                            ft.Text("Изменяйте остаток кнопками + / −", size=13, color=ft.Colors.GREY_600),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    self.product_list,
                ],
            )
        )
        self.refresh()

    def make_header(self) -> ft.Container:
        return ft.Container(
            padding=ft.Padding.symmetric(horizontal=22, vertical=18),
            bgcolor=ft.Colors.BLUE_GREY_900,
            border_radius=18,
            content=ft.Row(
                spacing=16,
                controls=[
                    ft.Container(
                        width=54,
                        height=54,
                        alignment=ft.Alignment.CENTER,
                        bgcolor=ft.Colors.BLUE_GREY_700,
                        border_radius=15,
                        content=ft.Icon(ft.Icons.INVENTORY_2, color=ft.Colors.WHITE, size=29),
                    ),
                    ft.Column(
                        tight=True,
                        spacing=4,
                        controls=[
                            ft.Text("Склад", size=25, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                            ft.Text("Обзор товарных запасов", size=14, color=ft.Colors.BLUE_GREY_100),
                        ],
                    ),
                    ft.Container(expand=True),
                    ft.Button(
                        content=ft.Text("Добавить товар"),
                        icon=ft.Icons.ADD,
                        color=ft.Colors.WHITE,
                        bgcolor=ft.Colors.BLUE_700,
                        on_click=self.add_product,
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def make_summary(self) -> ft.Row:
        return ft.Row(
            wrap=True,
            spacing=12,
            run_spacing=12,
            controls=[
                self.stat_card("Товары", self.total_products, ft.Icons.INVENTORY, ft.Colors.BLUE_700),
                self.stat_card("Единиц на складе", self.total_units, ft.Icons.LAYERS, ft.Colors.TEAL_700),
                self.stat_card("Мало на складе · ≤ 5", self.low_stock, ft.Icons.WARNING_AMBER, ft.Colors.AMBER_700),
                self.stat_card("Стоимость запасов", self.total_value, ft.Icons.PAYMENTS, ft.Colors.GREEN_700),
            ],
        )

    @staticmethod
    def stat_card(label: str, value: ft.Text, icon: str, accent: str) -> ft.Container:
        return ft.Container(
            width=230,
            padding=16,
            bgcolor=ft.Colors.WHITE,
            border=ft.Border.all(1, ft.Colors.GREY_200),
            border_radius=15,
            content=ft.Row(
                spacing=12,
                controls=[
                    ft.Container(
                        width=42,
                        height=42,
                        alignment=ft.Alignment.CENTER,
                        bgcolor=ft.Colors.GREY_100,
                        border_radius=12,
                        content=ft.Icon(icon, color=accent, size=22),
                    ),
                    ft.Column(
                        tight=True,
                        spacing=3,
                        controls=[
                            ft.Text(label, size=12, color=ft.Colors.GREY_600),
                            ft.Container(content=value),
                        ],
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def on_search(self, event) -> None:
        self.query = event.control.value or ""
        self.refresh()

    def on_category(self, event) -> None:
        self.category = event.control.value or "Все категории"
        self.refresh()

    def visible_products(self) -> list[InventoryProduct]:
        normalized_query = self.query.casefold().strip()
        matches: list[InventoryProduct] = []
        for product in self.catalog:
            matches_query = (
                not normalized_query
                or normalized_query in product.name.casefold()
                or normalized_query in product.sku.casefold()
            )
            matches_category = self.category == "Все категории" or product.category == self.category
            if matches_query and matches_category:
                matches.append(product)
        return sorted(matches)

    def refresh(self) -> None:
        products = self.catalog.products()
        self.total_products.value = str(len(products))
        self.total_units.value = str(sum(product.quantity for product in products))
        self.low_stock.value = str(sum(product.quantity <= 5 for product in products))
        inventory_value = sum(product.quantity * product.price for product in products)
        self.total_value.value = f"{inventory_value:,.2f} ₽"

        categories = ["Все категории"]
        for product in products:
            if product.category not in categories:
                categories.append(product.category)
        self.category_dropdown.options = [ft.DropdownOption(text=item) for item in categories]
        if self.category not in categories:
            self.category = "Все категории"
        self.category_dropdown.value = self.category
        self.product_list.controls = [self.product_card(product) for product in self.visible_products()]
        self.page.update()

    def product_card(self, product: InventoryProduct) -> ft.Container:
        stock_color = ft.Colors.RED_700 if product.quantity <= 5 else ft.Colors.GREEN_700
        stock_bg = ft.Colors.RED_50 if product.quantity <= 5 else ft.Colors.GREEN_50
        return ft.Container(
            padding=ft.Padding.symmetric(horizontal=18, vertical=14),
            bgcolor=ft.Colors.WHITE,
            border=ft.Border.all(1, ft.Colors.GREY_200),
            border_radius=14,
            content=ft.Column(
                spacing=12,
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                tight=True,
                                spacing=3,
                                controls=[
                                    ft.Text(product.name, size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text(f"Артикул {product.sku}", size=12, color=ft.Colors.GREY_600),
                                ],
                            ),
                            ft.Container(expand=True),
                            ft.Container(
                                padding=ft.Padding.symmetric(horizontal=11, vertical=7),
                                bgcolor=stock_bg,
                                border_radius=18,
                                content=ft.Text(
                                    f"На складе: {product.quantity}",
                                    size=12,
                                    weight=ft.FontWeight.BOLD,
                                    color=stock_color,
                                ),
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Row(
                        wrap=True,
                        spacing=10,
                        run_spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            ft.Container(
                                padding=ft.Padding.symmetric(horizontal=10, vertical=5),
                                bgcolor=ft.Colors.BLUE_GREY_50,
                                border_radius=12,
                                content=ft.Text(product.category, size=12, color=ft.Colors.BLUE_GREY_700),
                            ),
                            ft.Text(f"{product.price:.2f} ₽ / шт.", size=13, color=ft.Colors.GREY_700),
                            ft.IconButton(
                                icon=ft.Icons.REMOVE,
                                icon_color=ft.Colors.BLUE_GREY_700,
                                bgcolor=ft.Colors.GREY_100,
                                tooltip="Уменьшить остаток на 1",
                                disabled=product.quantity == 0,
                                on_click=lambda event, item=product: self.adjust_stock(item, -1),
                            ),
                            ft.IconButton(
                                icon=ft.Icons.ADD,
                                icon_color=ft.Colors.WHITE,
                                bgcolor=ft.Colors.BLUE_700,
                                tooltip="Увеличить остаток на 1",
                                on_click=lambda event, item=product: self.adjust_stock(item, 1),
                            ),
                        ],
                    ),
                ],
            ),
        )

    def adjust_stock(self, product: InventoryProduct, amount: int) -> None:
        product.change_quantity(amount)
        self.refresh()

    def add_product(self) -> None:
        serial = len(self.catalog) + 1
        sku = f"NEW-{serial:03d}"
        while self.catalog.find(sku) is not None:
            serial += 1
            sku = f"NEW-{serial:03d}"
        self.catalog.add(InventoryProduct(sku, f"Новый товар {serial}", "Новинки", 1, 9.99))
        self.category = "Все категории"
        self.refresh()


def main(page: ft.Page) -> None:
    InventoryWindow(page).build()


ft.run(main)
