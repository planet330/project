from abc import ABC, abstractmethod


class AbstractEntity(ABC):
    @abstractmethod
    def display_name(self) -> str:
        raise NotImplementedError


class InventoryProduct(AbstractEntity):
    def __init__(self, sku: str, name: str, category: str, quantity: int, price: float):
        self.sku = sku
        self.name = name
        self.category = category
        self.quantity = quantity
        self.price = price

    @property
    def sku(self) -> str:
        return self._sku

    @sku.setter
    def sku(self, value: str) -> None:
        normalized = value.strip().upper()
        if not normalized:
            raise ValueError("SKU cannot be empty")
        self._sku = normalized

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Product name cannot be empty")
        self._name = cleaned

    @property
    def category(self) -> str:
        return self._category

    @category.setter
    def category(self, value: str) -> None:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Category cannot be empty")
        self._category = cleaned

    @property
    def quantity(self) -> int:
        return self._quantity

    @quantity.setter
    def quantity(self, value: int) -> None:
        if not isinstance(value, int) or value < 0:
            raise ValueError("Quantity must be a non-negative integer")
        self._quantity = value

    @property
    def price(self) -> float:
        return self._price

    @price.setter
    def price(self, value: float) -> None:
        if value < 0:
            raise ValueError("Price cannot be negative")
        self._price = float(value)

    def display_name(self) -> str:
        return self.name

    def change_quantity(self, amount: int) -> None:
        updated = self.quantity + amount
        if updated < 0:
            raise ValueError("Stock cannot be negative")
        self.quantity = updated

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, InventoryProduct):
            return NotImplemented
        return self.sku == other.sku

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, InventoryProduct):
            return NotImplemented
        return (self.name.casefold(), self.sku) < (other.name.casefold(), other.sku)

    def __repr__(self) -> str:
        return (
            f"InventoryProduct(sku={self.sku!r}, name={self.name!r}, "
            f"category={self.category!r}, quantity={self.quantity}, price={self.price:.2f})"
        )

    def __str__(self) -> str:
        return f"{self.name} · {self.sku} · {self.quantity} in stock"


class ProductIndex(AbstractEntity):
    """A small SKU-to-product mapping implemented with a list of pairs."""

    def __init__(self, entries: list[tuple[str, InventoryProduct]] | None = None):
        self.entries = entries or []

    @property
    def entries(self) -> list[tuple[str, InventoryProduct]]:
        return self._entries

    @entries.setter
    def entries(self, value: list[tuple[str, InventoryProduct]]) -> None:
        validated: list[tuple[str, InventoryProduct]] = []
        for key, product in value:
            if not isinstance(product, InventoryProduct):
                raise TypeError("Index values must be InventoryProduct objects")
            normalized = key.strip().upper()
            if any(existing_key == normalized for existing_key, _ in validated):
                raise ValueError(f"Duplicate SKU: {normalized}")
            validated.append((normalized, product))
        self._entries = validated

    def display_name(self) -> str:
        return "Product SKU index"

    def add(self, product: InventoryProduct) -> None:
        if self.find(product.sku) is not None:
            raise ValueError(f"SKU already exists: {product.sku}")
        self._entries.append((product.sku, product))

    def find(self, sku: str) -> InventoryProduct | None:
        key = sku.strip().upper()
        for current_key, product in self._entries:
            if current_key == key:
                return product
        return None

    def remove(self, sku: str) -> bool:
        key = sku.strip().upper()
        for position, (current_key, _) in enumerate(self._entries):
            if current_key == key:
                self._entries.pop(position)
                return True
        return False

    def products(self) -> list[InventoryProduct]:
        return [product for _, product in self._entries]

    def __len__(self) -> int:
        return len(self._entries)

    def __iter__(self):
        return iter(self.products())

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProductIndex):
            return NotImplemented
        return self._entries == other._entries

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, ProductIndex):
            return NotImplemented
        return len(self) < len(other)

    def __repr__(self) -> str:
        return f"ProductIndex(entries={self._entries!r})"

    def __str__(self) -> str:
        return f"SKU index with {len(self)} products"

    @staticmethod
    def seed_inventory() -> ProductIndex:
        products = [
            InventoryProduct("EL-104", "Беспроводные наушники", "Электроника", 18, 79.90),
            InventoryProduct("EL-118", "USB-C концентратор", "Электроника", 7, 34.50),
            InventoryProduct("EL-125", "Настольная лампа", "Электроника", 4, 42.00),
            InventoryProduct("OF-210", "Блокнот в твёрдой обложке", "Канцелярия", 32, 8.75),
            InventoryProduct("OF-224", "Набор гелевых ручек", "Канцелярия", 14, 12.40),
            InventoryProduct("OF-231", "Органайзер для стола", "Канцелярия", 5, 19.95),
            InventoryProduct("HM-302", "Керамическая кружка", "Дом", 21, 15.00),
            InventoryProduct("HM-317", "Хлопковый плед", "Дом", 3, 46.00),
            InventoryProduct("HM-329", "Стеклянная банка", "Дом", 11, 13.25),
            InventoryProduct("SP-410", "Коврик для йоги", "Спорт", 9, 28.00),
            InventoryProduct("SP-426", "Стальная бутылка", "Спорт", 2, 24.90),
            InventoryProduct("SP-438", "Эспандеры", "Спорт", 16, 17.50),
        ]
        index = ProductIndex()
        for product in products:
            index.add(product)
        return index
